"use server"
import { blogModel } from "../../../../app/models/blog.model";
import { NextResponse } from "next/server";

export async function GET(request) {

    const blogmodel=await blogModel();
    if(!blogmodel)
    {
        return NextResponse.json({status:false,message:"database error occured"});
    }

    try {
        const bloglist=await blogmodel.findAll({order:[['blogSerial','ASC']]});
        return NextResponse.json({status:true,bloglist});

    } catch (error) {
        
        console.log(error);
        return NextResponse.json({status:false,message:"some error occured"});
        
    }

}